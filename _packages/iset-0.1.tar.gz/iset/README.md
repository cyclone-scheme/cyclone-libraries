Chibi's iset library

Copyright (c) 2004-2017 Alex Shinn. All rights reserved.
BSD-style license: http://synthcode.com/license.txt

A space efficient integer set (iset) implementation, optimized for
minimal space usage and fast membership lookup.  General set
operations are provided based on the character set operations
found in SRFI-14.
