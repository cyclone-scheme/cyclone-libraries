A sample library demonstrating how to create a package.
