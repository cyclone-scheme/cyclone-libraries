Chibi's char-set library

Copyright (c) 2004-2017 Alex Shinn. All rights reserved.
BSD-style license: http://synthcode.com/license.txt

A minimal character set library.
