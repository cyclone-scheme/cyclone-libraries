Chibi's cursor-oriented string library

Copyright (c) 2004-2017 Alex Shinn. All rights reserved.
BSD-style license: http://synthcode.com/license.txt

A cursor-oriented string library.  Provides efficient string
utilities for implementations with or without fast random-access
strings.

